#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <ctype.h>

//This is a struct used to access the semaphores
typedef struct _rwloct_t{
    sem_t lock;
    sem_t writelock;
    int readers;
}rwlock_t;

//So I used this global variable to help me starve the readers, it is assigned origianlly to 0
//But when a writer is writing this value is assigned as 1 to call semwait on the reader fcn using semaphore: lock
int blockval=1;

//FUNCTION: This function is used inside my reader and writer function to initialize my semaphores
void rwlock_init(rwlock_t *rw) { 
   rw->readers = 0;
   sem_init(&rw->lock, 0, 1);//DEBUG: In the future you may want to change this to 0 for reader to wait to let writer
   sem_init(&rw->writelock, 0, 1);
   return; 
}
//FUNCTION: This function is used inside my reader function to acquire a reader thread
void rwlock_acquire_readlock(rwlock_t *rw) { 
   if(blockval>0){
       printf("Writer is reading, you must wait\n");
	    sem_wait(&rw->lock);//if a writer has entered to write this condition will cause a reader to wait sleeping on lock
	}
	else if(blockval<1){
        sem_wait(&rw->writelock);//This will pause a reader if another reader is reading
	
	sem_post(&rw->writelock); //This will awake a reader or writer right away to make everyong take turns fairly
   	}
	return;
} 
//FUNCTION: This function is used inside my reader function to release a reader thread
void rwlock_release_readlock(rwlock_t *rw) { 
   if(blockval<1){
	sem_post(&rw->lock); //In case a writer is waiting 
   }
   	return;
} 
//FUNCTION: This function is used inside my writer function to acquire a writer thread
void rwlock_acquire_writelock(rwlock_t *rw) { 
    blockval=1;//This assignment will cause any reader after writer to pause until writer has finished writing
    printf("wait for writer\n");
    sem_wait(&rw->writelock); //Calling semwait for a writer that is behind another writer
    sem_post(&rw->writelock); //This will awake a reader or writer right away to make everyong take turns fairly
	return;
} 
//FUNCTION: This function is used inside my writer function to release a writer thread
void rwlock_release_writelock(rwlock_t *rw) { 
   sem_post(&rw->writelock); //Waking up anyone next in line 
   blockval=0;//This will avoid a reader from being put to sleep because a writer is done writing
   sem_post(&rw->lock); //waking up a sleeping reader 
	return;
} 
//Funciton to waste time for the acquire and wait functions to operate while a person is reading or writing data
void reading_writing(){
	int t;  
	int i;
	int j;
	t = rand()%10000; 
	for(i = 0; i < t; i++){
		for(j = 0; j< t; j++){ 
		}
	}
	return;
}



