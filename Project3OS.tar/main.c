#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <ctype.h>


//This is a struct used to access the semaphores
typedef struct _rwloct_t{
    sem_t lock;
    sem_t writelock;
    int readers;
}rwlock_t;

//functions from readers writers
void rwlock_init (rwlock_t* rw);
void rwlock_acquire_readlock (rwlock_t* rw);
void rwlock_release_readlock (rwlock_t* rw);
void rwlock_acquire_writelock (rwlock_t* rw);
void rwlock_release_writelock (rwlock_t* rw);
void reading_writing(void);


//Writer
rwlock_t w;//this is a struct type to access the semaphores in the function calls in side reader and writer
void* writer(void* arg){
rwlock_init(&w);

rwlock_acquire_writelock(&w);

reading_writing();

rwlock_release_writelock(&w);
//This is revealing order of the reader and writer
printf("Writer Done\n");
return 0;
}
//Reader
void*reader(void* arg)
{

	rwlock_init(&w);

	rwlock_acquire_writelock(&w);

	reading_writing();

	rwlock_release_writelock(&w);
	//This is revealing order of the reader and writer
	printf("Reader Done\n");
	return 0;
}



int main(){

    //variable to access reader and writer characters in the scenario text file to read
char ch;
//Count for number of readers and writers to find the number of readers and writers 
int i, readct, writect=0;
//readct, writect=0;

//Opening File, fp is my pointer
FILE* fp = fopen("scenarios.txt", "r");

//need to get the count for threads reads and write after you read in r count and w count
if(fp==NULL){
	printf("File is not available \n");
}
else{
	printf("Reading File");
	while((ch=fgetc(fp))!=EOF){
		printf("Character:\n %c", ch);
		if(ch=='w'){
			writect++;
		}
		else if(ch=='r'){
			readct++;
		}
	}
}
//This is just explaing the order of the text files for readers and writers
printf("Write count is: %d\n Read count is: %d\n", writect, readct);

//Creating Threads process
pthread_t read[5], write[5];
//READ THREADS
for(i = 0; i < readct; i++) {
   printf("Creating a read thread\n");
   pthread_create(&read[i], NULL, reader, NULL);
}
//WRITER THREADS
for(i = 0; i < writect; i++) {
    printf("Creating a write thread\n");
    pthread_create(&write[i], NULL, writer,NULL);
}
//JOINING THREADS
for(i = 0; i < readct; i++) {
        pthread_join(read[i], NULL);
}
for(i = 0; i < writect; i++) {
        pthread_join(write[i], NULL);
}
//Close my file
fclose(fp);
return 0; 
        


}
